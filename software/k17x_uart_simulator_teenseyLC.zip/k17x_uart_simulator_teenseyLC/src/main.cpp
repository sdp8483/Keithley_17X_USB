#include <Arduino.h>

#define LED         13
#define MAX_COUNT   20000
#define MIN_COUNT   -20000
#define INCREMENT   100
#define PRINT_RATE  10.0  // Hz
#define COUNT_RATE  2.0   // Hz
#define PRINT_WAIT  int((1/PRINT_RATE) * 1000)
#define COUNT_WAIT  int((1/COUNT_RATE) * 1000)

// Prototype Statements
int update_value(void);
void print_value(int);

void setup() {
  Serial.begin(115200);

  pinMode(LED, OUTPUT);
}

void loop() {
  while(1) {
    int val = update_value();
    print_value(val);
  }
}

int update_value() {
  static unsigned long last_update = 0;
  static bool count_up = true;
  static int count = 0;

  if ((millis() - last_update) >= COUNT_WAIT) {
    last_update = millis();

    // Change value
    if (count_up == true) {
      count += INCREMENT;
    } else {
      count -= INCREMENT;
    }

    // limits on value
    if (count >= MAX_COUNT) {
      count = MAX_COUNT;
      count_up = false;
    } else if (count <= MIN_COUNT) {
      count = MIN_COUNT;
      count_up = true;
    }
  } // end timing loop

  return count;
} // end update_value()

void print_value(int i) {
  static unsigned long last_print = 0;

  if ((millis() - last_print) >= PRINT_WAIT) {
    last_print = millis();
      Serial.print('\x00'); // print null character

      // Print Sign
      if (i >= 0) {
        Serial.print('+');
      } else {
        Serial.print('-');
      }

      // Print Leading Zeros
      i = abs(i);
      if(i < 10000) {
        Serial.print('0');
      }
      if(i < 1000) {
        Serial.print('0');
      }
      if(i < 100) {
        Serial.print('0');
      }
      if(i < 10) {
        Serial.print('0');
      }
      
      // Print the value
      Serial.print(i);

      // Finaly print the ending characters
      Serial.print('\r');  
      Serial.print('\n');
  } // end timing loop
} // end print_value